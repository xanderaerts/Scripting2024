# Olympic Knowledge

With this package you can get information about water polo on the Olympic games.
All methods generate a pdf.

## General methods 
- General()

This method generates a pdf with all the basic information about Water polo.

## Country
- Country(country)

This method generates a pdf with all the medalists from a given country. 

## Year
- Year(year)

This method generates a pdf with all medalists from a given year.

## Athlete
- Athlete(name)

This method generates a pdf with all the information about an Athlete.
